 <p align="center">  
  <a href="">
    <img alt="PRINCE" width="600" height="350" src="https://i.imgur.com/iI086tX.jpeg">
  </a>
</p>



<p align="center">
<a href="https://github.com/PRINCE-GDS/THE-PRINCE-BOT"><img title="Author" src="https://img.shields.io/badge/THE PRINCE BOT-black?style=for-the-badge&logo=github"></a>
<p/>

<p align="center">
<a href="https://github.com/PRINCE-GDS?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/PRINCE-GDS?label=Followers&style=social"></a>
<a href="https://github.com/PRINCE-GDS/THE-PRINCE-BOT/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/PRINCE-GDS/THE-PRINCE-BOT?&style=social"></a>
<a href="https://github.com/PRINCE-GDS/THE-PRINCE-BOT/network/members"><img title="Fork" src="https://img.shields.io/github/forks/PRINCE-GDS/THE-PRINCE-BOT?style=social"></a>
<a href="https://github.com/PRINCE-GDS/THE-PRINCE-BOT/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/PRINCE-GDS/THE-PRINCE-BOT?label=Watching&style=social"></a>
</p>
 
<h1 align="center">🛡️ᑭᖇIᑎᑕᕮ ᗷOT ᗰᗪ🛡️</h1>

#### 🪩 To Change the owner number click here [CHANGE ONWER](https://github.com/PRINCE-GDS/THE-PRINCE-BOT/blob/main/plugins/main-creator.js#L7)🪩

<h2 align="left">ＳＥＳＳＩＯＮ ＩＤ (ＰＡＩＲ ＣＯＤＥ)</h2>
<p align="left">
<a href="https://replit.com/@iycwwwuaaipgfjs/Prince-PairCode?v=1"><img height= "40" title="Author" src="https://img.shields.io/badge/SESSION ID-black?style=for-the-badge&logo=replit"></a>
<p/>

****
#### If pair code don't work then scan QR for session ID


<h2 align="left">ＳＥＳＳＩＯＮ ＩＤ (QR SCAN)</h2>

<a href="https://princebotqr.onrender.com/"><img height= "40" title="Author" src="https://img.shields.io/badge/SESSION ID-black?style=for-the-badge&logo=render"></a>
<p/>


<h1 align="left">ÐΣPLOY TO HΣЯOKU</h1> 

#### 1. If You don't have an account in Heroku. Create an account.
<br>
       <p align="left"><a href="https://signup.heroku.com"> <img src="https://img.shields.io/badge/heroku%20Account-purple?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>

#### 2. Deploy Now.
   <p align="left"><a href="https://heroku.com/deploy?template=https://github.com/PRINCE-GDS/THE-PRINCE-BOT"> <img src="https://img.shields.io/badge/Heroku%20Deploy-purple?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>



<h1 align="left">ÐΣPLOY TO REPLIT</h1> 

1. If You don't have an account in Replit. Create a account.
    <br>
<p align="left"><a href="https://replit.com/signup"> <img src="https://img.shields.io/badge/replit%20Account-purple?style=for-the-badge&logo=replit" width="220" height="38.45"/></a></p>

2. Now Deploy
    <br>
<p align="left"><a href="https://repl.it/github/PRINCE-GDS/THE-PRINCE-BOT"> <img src="https://img.shields.io/badge/replit%20Deploy-purple?style=for-the-badge&logo=replit" width="220" height="38.45"/></a></p>

<h2 align="left">DEPLOY TO KOYEB</h2> 

#### 1. if you don't have a koyeb account. Create an account.
   <br>
   <p align="left"><a href="https://app.koyeb.com/auth/signup"> <img src="https://img.shields.io/badge/Koyeb account-purple?style=for-the-badge&logo=koyeb" width="220" height="38.45"/></a></p>

#### 2. Now deploy
   <br>
  <p align="left"><a href="https://app.koyeb.com/apps/deploy?type=git&repository=github.com%2FPRINCE-GDS%2FTHE-PRINCE-BOT&branch=main&nameprincegds&builder=dockerfile&env[DATABASE_URL]=&env[SESSION_ID]=your+sessionid+here&env[PREFIX]=!&env[MODE]=public&env=[autoRead]=false&env[statusview]=false&env[REMOVEBG_KEY]=your+rmbg+key&env[antidelete]=false"> <img src="https://www.koyeb.com/static/images/deploy/button.svg" width="140" height="45.45"/></a></p>


<h1 align="left">suᴘᴘoʀт ԍʀouᴘ ʟιɴκ</h1>



   <p align="left">
      <a href="https://chat.whatsapp.com/Jo5bmHMAlZpEIp75mKbwxP"><img height= "40" length= "10" title="Author" src="https://img.shields.io/badge/Support Group-25D366?style=for-the-badge&logo=whatsApp&logoColor=white"></a>
     <p/>



 


### TERMUX
1. 
```sh
$ pkg upgrade -y && pkg update -y
$ pkg install git -y
$ pkg install nodejs -y
$ pkg install ffmpeg -y
$ pkg install imagemagick -y
$ git clone https://github.com/PRINCE-GDS/THE-PRINCE-BOT
$ cd THE-PRINCE-BOT
$ npm i 
$ npm start
```
2. Wait for the to start...
3. Scan the QR code from the second device. (Go to WhatsApp > Linked Devices > Link a Device) 
---------

<h2 align="left">All Credits To Guru bruh</h2>

<a href="https://github.com/Guru322"><img src="https://github.com/Guru322.png" width="70" height="70" alt="Guru322"/></a>
  
`GURU-bhay Guru322`

