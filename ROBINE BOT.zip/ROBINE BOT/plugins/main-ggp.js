let handler = async m => m.reply(`
★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆
≡★☆🅟🅡🅘🅝🅒🅔 🅣🅗🅔 🅞🅦🅝🅔🅡☆★≡

★𝚂𝚄𝙿𝙿𝙾®𝚃 𝙶𝚁𝙾𝚄𝙿 𝙻𝙸𝙽𝙺★
─────────────
▢ ★☆☆🛡️𝘗𝘙𝘐𝘕𝘊𝘌-𝘉𝘖𝘛-𝘔𝘋🛡️☆☆★

🅛🅘🅝🅚: https://chat.whatsapp.com/Jo5bmHMAlZpEIp75mKbwxP

🅛🅘🅝🅚: https://whatsapp.com/channel/0029VaKNbWkKbYMLb61S1v11

★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★
★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆
 
★   ☆   ★   ☆   ★   ☆   ★   ☆
┊   ┊　　┊　　┊　　┊
┊   ┊　　┊　　┊　　★
┊   ┊　　┊　　☆
┊   ┊　　★
┊   ☆
★${developer}★
★☆🅞🅦🅝🅔🅡 🅝🅤🅜🅑🅔🅡☆★
★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★
`.trim())
handler.help = ['gpprince']
handler.tags = ['main']
handler.command = ['groups', 'groupprince', 'gugp', 'ggp', 'support'] 

export default handler
